/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package studentprojectpartb.pkg3;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JButton;
import javax.swing.JLabel;

/**
 *
 * @author natas
 */


public class StudentProjectPartB3 extends javax.swing.JFrame {

    /**
     * Creates new form NewJFrame
     */
    public StudentProjectPartB3() {
        initComponents();

    }

    static double forLoopElapsedTime = 0;
    static double whileLoopElapsedTime = 0;
    static double doWhileLoopElapsedTime = 0;
    
    static double forAvg = 0.0;
    static double whileAvg = 0.0;        
    static double doWhileAvg = 0.0;  
    
    private static DecimalFormat df2 = new DecimalFormat(".####");    

    //For Loop Execution
    public static void calculateForLoopExecTime() {
        double startTime = System.currentTimeMillis();
        long total = 0;
        for (int i = 0; i < 100000000; i++) {
            total += i;
        }
        double stopTime = System.currentTimeMillis();
        forLoopElapsedTime = (stopTime - startTime) / 1000;
    }

    //While Loop Execution
    public static void calculateWhileLoopExecTime() {
        double startTime = System.currentTimeMillis();
        long total = 0;
        long i = 0;
        while (i < 100000000) {
            total += i;
            i++;
        }
        double stopTime = System.currentTimeMillis();
        whileLoopElapsedTime = (stopTime - startTime) / 1000;
    }

    //DoWhile Loop Execution
    public static void calculateDoWhileLoopExecTime() {
        double startTime = System.currentTimeMillis();
        long total = 0;
        long i = 0;
        do {
            total += i;
            i++;
        } while (i < 100000001);
        double stopTime = System.currentTimeMillis();
        doWhileLoopElapsedTime = (stopTime - startTime) / 1000;
    }
 
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        jLabel1 = new JLabel();
        jLabel2 = new JLabel();
        jLabel3 = new JLabel();
        jLabel4 = new JLabel();
        jLabel5 = new JLabel();
        jLabel6 = new JLabel();
        jLabel7 = new JLabel();
        jLabel8 = new JLabel();
        jLabel9 = new JLabel();
        jButton1 = new JButton();
        jButton2 = new JButton();
        jButton3 = new JButton();
        jButton4 = new JButton();
        jLabel10 = new JLabel();
        jLabel11 = new JLabel();
        jLabel12 = new JLabel();
        jLabel13 = new JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setText("Start Time");
        jLabel2.setText("");
        jLabel3.setText("End Time");
        jLabel4.setText("");
        jLabel5.setText("Elapsed Time");
        jLabel6.setText("");
        jLabel7.setText("number of seconds");
        jLabel8.setText("Completed Loops");
        jLabel9.setText("");

        jButton1.setText("While Loop");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jButton2.setText("For Loop");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jButton3.setText("Do While Loop");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        
        jButton4.setText("Clear All");
        jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton4ActionPerformed(evt);
            }
        });

        jLabel10.setText("Elapsed Time for 10,000 Loops (in fraction of seconds)");
        jLabel11.setText("");
        jLabel12.setText("");
        jLabel13.setText("");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 376, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 24, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel2))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel3)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel4))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel5)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel6)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel7))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel9))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jButton1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton3)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jButton4))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel11)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel13)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(jLabel9))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton1)
                    .addComponent(jButton2)
                    .addComponent(jButton3)
                    .addComponent(jButton4))
                .addGap(18, 18, 18)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(jLabel12)
                    .addComponent(jLabel13))
                .addContainerGap(93, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>                        
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) 
    {                                         
        // While Loop
        jLabel2.setText(new SimpleDateFormat("hh:mm:ss a").format(new Date()));
          calculateForLoopExecTime();
          calculateWhileLoopExecTime();
          calculateDoWhileLoopExecTime();
        jLabel6.setText(df2.format(whileLoopElapsedTime));          
        jLabel4.setText(new SimpleDateFormat("hh:mm:ss a").format(new Date()));      
        jLabel9.setText("10,000");
        jLabel11.setText(df2.format(whileLoopElapsedTime));
        jLabel12.setText(df2.format(forLoopElapsedTime));
        jLabel13.setText(df2.format(doWhileLoopElapsedTime));
    }                                        
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        // For Loop
        jLabel2.setText(new SimpleDateFormat("hh:mm:ss a").format(new Date()));
          calculateForLoopExecTime();
          calculateWhileLoopExecTime();
          calculateDoWhileLoopExecTime();
        jLabel6.setText(df2.format(forLoopElapsedTime));          
        jLabel4.setText(new SimpleDateFormat("hh:mm:ss a").format(new Date()));      
        jLabel9.setText("10,000");      
        jLabel11.setText(df2.format(whileLoopElapsedTime));
        jLabel12.setText(df2.format(forLoopElapsedTime));
        jLabel13.setText(df2.format(doWhileLoopElapsedTime));
    }                                        
    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        // Do While Loop
        jLabel2.setText(new SimpleDateFormat("hh:mm:ss a").format(new Date()));
          calculateForLoopExecTime();
          calculateWhileLoopExecTime();
          calculateDoWhileLoopExecTime();
        jLabel6.setText(df2.format(doWhileLoopElapsedTime));
        jLabel4.setText(new SimpleDateFormat("hh:mm:ss a").format(new Date()));      
        jLabel9.setText("10,000");        
        jLabel11.setText(df2.format(whileLoopElapsedTime));
        jLabel12.setText(df2.format(forLoopElapsedTime));
        jLabel13.setText(df2.format(doWhileLoopElapsedTime));
    }                                        
    private void jButton4ActionPerformed(java.awt.event.ActionEvent evt) 
    {                                         
        // Clears all the info
        jLabel2.setText("");
        jLabel4.setText("");
        jLabel6.setText("");
        jLabel9.setText("");        
        jLabel11.setText("");
        jLabel12.setText("");
        jLabel13.setText("");
    }                                        

    public static void main(String args[]) 
    {
        // Course Information
        System.out.println("IT-2650 Java Programming");
        System.out.println("Student Name: Natasha Ostrander");
        System.out.println("Homework Assignment: Student Project Part B");
        System.out.println("________________________________");
        System.out.println("");

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new StudentProjectPartB3().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify                     
    private JButton jButton1;
    private JButton jButton2;
    private JButton jButton3;
    private JButton jButton4;
    private JLabel jLabel1;
    private JLabel jLabel10;
    private JLabel jLabel11;
    private JLabel jLabel12;
    private JLabel jLabel13;
    private JLabel jLabel2;
    private JLabel jLabel3;
    private JLabel jLabel4;
    private JLabel jLabel5;
    private JLabel jLabel6;
    private JLabel jLabel7;
    private JLabel jLabel8;
    private JLabel jLabel9;
    
    private double forArray=0.0;
    private double whileArray=0.0;    
    private double doWhileArray=0.0;    
    
    // End of variables declaration                   
}
